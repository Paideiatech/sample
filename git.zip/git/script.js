let users = [];
const adminEmail = "paideiatechnologies@gmail.com";
const adminPassword = "admin";
const trialPeriodDays = 3;

function registerUser() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const enablerId = document.getElementById('enablerId').value;
    
    if (!email || !password) {
        alert("Email and password are required!");
        return;
    }

    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
        alert("User already registered!");
        return;
    }

    const expiryDate = new Date();
    if (!enablerId) {
        expiryDate.setDate(expiryDate.getDate() + trialPeriodDays);
    } else {
        expiryDate.setDate(expiryDate.getDate() + 365);
    }

    const user = { email, password, enablerId, expiryDate, isApproved: false };
    users.push(user);
    alert("User registered successfully! Please wait for admin approval.");
}

function loginUser() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    if (email === adminEmail && password === adminPassword) {
        alert("Admin login successful!");
        document.querySelector('.admin-panel').style.display = 'block';
        return;
    }

    const user = users.find(user => user.email === email && user.password === password);
    
    if (!user) {
        alert("Invalid login credentials!");
        return;
    }

    if (!user.isApproved) {
        alert("User is not approved by admin yet!");
        return;
    }

    const currentDate = new Date();
    if (currentDate > new Date(user.expiryDate)) {
        alert("Trial period expired. Please use an enabler ID to continue.");
        return;
    }

    showSimulation();
}

function showSimulation() {
    document.querySelector('.simulation-panel').style.display = 'block';
}

function logout() {
    document.querySelector('.admin-panel').style.display = 'none';
    document.querySelector('.simulation-panel').style.display = 'none';
    alert("Logged out successfully!");
}

function toggleValve() {
    const valveStatus = document.getElementById('valveStatus');
    valveStatus.textContent = valveStatus.textContent === "Closed" ? "Open" : "Closed";
}

function resetAdminPassword() {
    const resetEmail = prompt("Enter admin email for password reset:");
    if (resetEmail === adminEmail) {
        alert("Password reset link sent to " + adminEmail);
    } else {
        alert("Invalid admin email!");
    }
}
